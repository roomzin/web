#!/usr/bin/env python3
"""
generate_csvs.py

Generates properties.csv and packages.csv based on codecs.yml configuration.
"""

import argparse
import csv
import os
import random
import sys
import yaml
from datetime import date, timedelta
from typing import Dict, List
from pathlib import Path

# ------------------------------------------------------------------
# helpers
# ------------------------------------------------------------------
def load_codecs(codecs_path: str) -> Dict[str, List[str]]:
    """Load amenities and rate_cancels from YAML file."""
    try:
        with open(codecs_path, 'r', encoding='utf-8') as f:
            data = yaml.safe_load(f)
            
        # Validate required fields
        required_fields = ['amenities', 'rate_cancels']
        for field in required_fields:
            if field not in data:
                raise ValueError(f"Missing required field '{field}' in codecs.yml")
            if not isinstance(data[field], list):
                raise ValueError(f"Field '{field}' must be a list in codecs.yml")
                
        return data
    except FileNotFoundError:
        raise FileNotFoundError(f"Codecs file not found: {codecs_path}")
    except yaml.YAMLError as e:
        raise ValueError(f"Invalid YAML in {codecs_path}: {e}")

def pick_unique(items: List[str], k: int, rng: random.Random) -> str:
    """Return k unique items joined by '|'"""
    if len(items) < k:
        # If we don't have enough unique items, allow some repetition
        selected = []
        while len(selected) < k:
            remaining = k - len(selected)
            selected.extend(rng.sample(items, min(len(items), remaining)))
        # But still ensure we have exactly k items
        selected = selected[:k]
        return "|".join(selected)
    return "|".join(rng.sample(items, k=k))

def ensure_dir(path: str) -> None:
    os.makedirs(path, exist_ok=True)

# ------------------------------------------------------------------
# generators
# ------------------------------------------------------------------
def gen_properties(
    num_segments: int,
    props_per_segment: int,
    amenities: List[str],
    writer: csv.writer,
    rng: random.Random,
) -> int:
    """Write property rows; return total properties created."""
    writer.writerow([
        "PropertyID", "Segment", "Area", "PropertyType", "Category",
        "Stars", "Latitude", "Longitude", "Amenities"
    ])

    prop_counter = 0
    for seg_i in range(num_segments):
        segment = f"segment_{seg_i + 1}"
        area = f"area_{seg_i + 1}"
        base_lat = 40.7128 + seg_i * 0.5
        base_lon = -74.0060 + seg_i * 0.5

        for _ in range(props_per_segment):
            prop_counter += 1
            prop_id = f"prop_{prop_counter}"
            stars = 3 + (prop_counter % 3)          # 3,4,5
            amenity_cnt = 3 + (prop_counter % 3)    # 3,4,5
            selected_amenities = pick_unique(amenities, amenity_cnt, rng)

            lat = base_lat + (prop_counter % 10) * 0.001
            lon = base_lon + (prop_counter % 10) * 0.001

            writer.writerow([
                prop_id,
                segment,
                area,
                "hotel",
                "test",
                str(stars),
                f"{lat:.6f}",
                f"{lon:.6f}",
                selected_amenities,
            ])
    return prop_counter

def gen_packages(
    num_props: int,
    room_types: int,
    days: int,
    rate_cancels: List[str],
    writer: csv.writer,
    rng: random.Random,
    start_date: date,
) -> None:
    """Write room/package rows for every property/room-type/day."""
    writer.writerow([
        "PropertyID", "RoomType", "Date", "Availability",
        "FinalPrice", "RateCancel"
    ])

    for prop_num in range(1, num_props + 1):
        prop_id = f"prop_{prop_num}"
        for j in range(1, room_types + 1):
            room_type = f"room_{j}"
            availability = 5 + (prop_num + j) % 11
            final_price = 100 + (prop_num + j) * 10
            rc_cnt = 2 + ((prop_num + j) % 4)  # 2-5
            rate_cancel = pick_unique(rate_cancels, rc_cnt, rng)

            for d in range(days):
                cur_date = start_date + timedelta(days=d)
                writer.writerow([
                    prop_id,
                    room_type,
                    cur_date.isoformat(),
                    str(availability),
                    str(final_price),
                    rate_cancel,
                ])

# ------------------------------------------------------------------
# main
# ------------------------------------------------------------------
def main(argv=None):
    parser = argparse.ArgumentParser(
        description="Generate properties.csv and packages.csv based on codecs.yml"
    )
    parser.add_argument("--segments", type=int, required=True, help="Number of segments")
    parser.add_argument("--props-per-segment", type=int, required=True, help="Properties per segment")
    parser.add_argument("--room-types", type=int, required=True, help="Number of room types per property")
    parser.add_argument("--days", type=int, required=True, help="Number of days to generate")
    parser.add_argument("--data-dir", type=str, required=True, help="Directory containing codecs.yml and where CSVs will be written")
    parser.add_argument("--seed", type=int, default=42, help="Random seed for reproducibility")
    
    args = parser.parse_args(argv)
    
    # Ensure data directory exists
    ensure_dir(args.data_dir)
    
    # Load codecs
    codecs_path = os.path.join(args.data_dir, "codecs.yml")
    try:
        codecs = load_codecs(codecs_path)
    except Exception as e:
        print(f"Error loading codecs: {e}", file=sys.stderr)
        sys.exit(1)
    
    # Initialize random generator with seed
    rng = random.Random(args.seed)
    start_date = date.today()
    
    # Paths for output CSVs
    props_path = os.path.join(args.data_dir, "properties.csv")
    pkgs_path = os.path.join(args.data_dir, "packages.csv")
    
    # Generate CSVs
    with open(props_path, "w", newline="", encoding="utf-8") as pf, \
         open(pkgs_path, "w", newline="", encoding="utf-8") as rf:

        prop_writer = csv.writer(pf)
        pkg_writer = csv.writer(rf)

        num_props = gen_properties(
            args.segments,
            args.props_per_segment,
            codecs['amenities'],
            prop_writer,
            rng,
        )
        gen_packages(
            num_props,
            args.room_types,
            args.days,
            codecs['rate_cancels'],
            pkg_writer,
            rng,
            start_date,
        )

    print(f"Loaded codecs from: {codecs_path}")
    print(f"  - {len(codecs['amenities'])} amenities")
    print(f"  - {len(codecs['rate_cancels'])} rate cancels")
    print(f"Generated {num_props} properties -> {props_path}")
    print(f"Generated packages -> {pkgs_path}")

if __name__ == "__main__":
    main()