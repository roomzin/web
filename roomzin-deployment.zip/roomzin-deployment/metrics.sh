#!/bin/bash

token="abc123"
echo "TCP Bytes Received Total"
echo "========================"

for ip in 172.20.0.{10,11,12}; do
    # Get metrics, remove lines starting with #, then grep for our metric
    curl -s -H "Authorization: Bearer $token" "http://$ip:8080/metrics" | grep -v '^#' | grep 'tcp_bytes_received_total' | head -1
done