#!/bin/bash

# Exit on error
set -e

# Variables
NETWORK="roomzin-cluster"
SUBNET="172.20.0.0/16"
NODES=("roomzin-0:172.20.0.10" "roomzin-1:172.20.0.11" "roomzin-2:172.20.0.12")
IMAGE_BASE="roomzin-ssh"
SEED="roomzin-0,roomzin-1,roomzin-2"

# Ensure required files exist
if [ ! -f "roomzin" ] || [ ! -f "configs/auth.yml" ] || [ ! -f "configs/roomzin.yml" ]; then
    echo "Error: Missing required files (roomzin, configs/auth.yml, configs/roomzin.yml)"
    exit 1
fi
for node in "${NODES[@]}"; do
    NODE_NAME=${node%%:*}
    if [ ! -d "certs/${NODE_NAME}" ]; then
        echo "Error: Missing certs/${NODE_NAME}/"
        exit 1
    fi
done

# Clean up previous setup
echo "Cleaning up previous Docker resources..."
docker stop roomzin-{0..2} 2>/dev/null || true
docker rm roomzin-{0..2} 2>/dev/null || true
docker network rm $NETWORK 2>/dev/null || true
docker rmi ${IMAGE_BASE} 2>/dev/null || true
docker rmi $(docker images -f "dangling=true" -q) 2>/dev/null || true
# Create and clear data directories
echo "Setting up data directories..."
for node in "${NODES[@]}"; do
    NODE_NAME=${node%%:*}
    DATA_DIR="./data/$NODE_NAME"
    mkdir -p $DATA_DIR
    # Use sudo to remove root-owned files, but don't fail if no sudo available
    # sudo rm -rf $DATA_DIR/* 2>/dev/null || rm -rf $DATA_DIR/* 2>/dev/null || true
    echo "Created: $DATA_DIR"
done

# Create Docker network
echo "Creating Docker network: $NETWORK"
docker network create --subnet=$SUBNET $NETWORK

# Generate SSH key if not exists
if [ ! -f ~/.ssh/id_ed25519 ]; then
    echo "Generating SSH key..."
    ssh-keygen -t ed25519 -f ~/.ssh/id_ed25519 -N ""
fi

# Build single Docker image and start containers
echo "Building Docker image for Roomzin..."
docker build -t ${IMAGE_BASE} .
for node in "${NODES[@]}"; do
    NODE_NAME=${node%%:*}
    NODE_IP=${node##*:}
    echo "Starting container $NODE_NAME at $NODE_IP..."
    docker run -d --cap-add=NET_ADMIN --network $NETWORK --ip $NODE_IP \
       --name $NODE_NAME -h $NODE_NAME -e NODE_NAME=$NODE_NAME \
       -v $(pwd)/data/$NODE_NAME:/opt/roomzin/data \
       ${IMAGE_BASE}
done

# Wait briefly for containers to initialize
echo "Waiting for containers to initialize..."
sleep 1

# Copy SSH key to each container
echo "Copying SSH keys to containers..."
for node in "${NODES[@]}"; do
    NODE_IP=${node##*:}
    ssh-keygen -R $NODE_IP 2>/dev/null || true
    sshpass -p 'password' ssh-copy-id -i ~/.ssh/id_ed25519 -o StrictHostKeyChecking=no root@$NODE_IP
done

# Update /etc/hosts in each container
echo "Configuring /etc/hosts in containers..."
for node in "${NODES[@]}"; do
    NODE_NAME=${node%%:*}
    for host in "${NODES[@]}"; do
        HOST_NAME=${host%%:*}
        HOST_IP=${host##*:}
        docker exec $NODE_NAME bash -c "\
            if ! grep -q '$HOST_IP $HOST_NAME' /etc/hosts; then \
                echo '$HOST_IP $HOST_NAME' >> /etc/hosts; \
            fi"
    done
done

# Check certificates in each container
echo "Checking certificate files in containers..."
for node in "${NODES[@]}"; do
    NODE_NAME=${node%%:*}
    NODE_IP=${node##*:}
    echo "Checking certs for $NODE_NAME ($NODE_IP)..."
    docker exec $NODE_NAME bash -c "\
        for file in /opt/roomzin/certs/{cert.pem,key.pem,ca.pem}; do \
            if [ ! -f \"\$file\" ]; then \
                echo \"Error: Missing \$file\"; \
                exit 1; \
            fi; \
        done"
done

# Start Roomzin on each container via SSH
echo "Starting Roomzin on each container..."
for node in "${NODES[@]}"; do
    NODE_NAME=${node%%:*}
    NODE_IP=${node##*:}
    echo "Starting Roomzin on $NODE_NAME..."
    sshpass -p 'password' ssh -o StrictHostKeyChecking=no root@$NODE_IP \
        "/opt/roomzin/roomzin run-clustered --config /opt/roomzin/configs/roomzin.yml --node-id $NODE_NAME --shard-id shard1 --zone-id zone1 --seed $SEED --initial-voters $SEED > /opt/roomzin/roomzin.log 2>&1" &
done

sleep 5

# Verify cluster health with retries
echo "Verifying cluster health..."
for attempt in {1..3}; do
    echo "Health check attempt $attempt..."
    all_healthy=true
    for node in "${NODES[@]}"; do
        NODE_IP=${node##*:}
        HEALTH=$(curl -s -H "Authorization: Bearer abc123" http://$NODE_IP:8080/healthz)
        PEERS=$(curl -s -H "Authorization: Bearer abc123" http://$NODE_IP:8080/peers)
        echo "Node at $NODE_IP: Health=$HEALTH, Peers=$PEERS"
        if [[ "$HEALTH" != "active_leader" && "$HEALTH" != "active_follower" ]]; then
            echo "Error: Node at $NODE_IP is not healthy"
            all_healthy=false
        fi
    done
    if [ "$all_healthy" = true ]; then
        break
    fi
    if [ $attempt -lt 3 ]; then
        echo "Retrying in 2 seconds..."
        sleep 2
    else
        echo "Error: Cluster health check failed after 3 attempts"
        exit 1
    fi
done

# Check Roomzin logs for each container
# echo "Checking Roomzin logs..."
# for node in "${NODES[@]}"; do
#     NODE_NAME=${node%%:*}
#     NODE_IP=${node##*:}
#     echo "Logs for $NODE_NAME ($NODE_IP):"
#     docker exec $NODE_NAME bash -c "cat /opt/roomzin/roomzin.log || echo 'No logs found'"
# done

echo "Roomzin 3-node cluster is up! Test with SDKs (tcp port 7777, api port 8080, hosts: roomzin-0,roomzin-1,roomzin-2)."
echo "To stop and clean up: make stop"